document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("myForm");
    const errorMessage = document.getElementById("error-message");

    form.addEventListener("submit", function (event) {
        const name = document.getElementById("name").value;
        const email = document.getElementById("email").value;

        if (!validateEmail(email)) {
            errorMessage.textContent = "Please enter a valid email address.";
            event.preventDefault();
        } else if (name.length < 3) {
            errorMessage.textContent = "Name must be at least 3 characters long.";
            event.preventDefault();
        }
    });

    function validateEmail(email) {
        const re = /\S+@\S+\.\S+/;
        return re.test(email);
    }
});
